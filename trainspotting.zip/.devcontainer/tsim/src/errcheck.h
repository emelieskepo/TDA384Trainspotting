
#ifndef TS_errcheck_H_
#define TS_errcheck_H_

int errcheck(
      int i,
      int ec,
      char *s);

void* errcheck_ptr(
      void *i,
      void *ec,
      char *s);

#endif /* TS_errcheck_H_ */

